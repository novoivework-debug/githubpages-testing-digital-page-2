import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";

export default function SearchSection() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showResults, setShowResults] = useState(false);

  const handleSearch = () => {
    if (searchTerm.trim()) {
      setShowResults(true);
    } else {
      setShowResults(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <section className="mb-16">
      <h2 className="text-2xl font-normal text-usbank-blue mb-6" data-testid="heading-search">
        Search customer service
      </h2>
      <div className="relative">
        <Input
          type="text"
          placeholder="How can we help you?"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyPress={handleKeyPress}
          className="w-full px-12 py-4 text-base border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-usbank-blue focus:border-usbank-blue"
          data-testid="input-search"
        />
        <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
          <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
      </div>

      {showResults && (
        <div className="mt-6" data-testid="search-results">
          <div className="text-gray-600 mb-4">
            <p>
              Hmm, we did not find any results for "
              <span className="font-semibold" data-testid="text-search-term">
                {searchTerm}
              </span>
              "
            </p>
            <p>Try a different search term or check out some of our tips below.</p>
          </div>

          <div className="mb-6">
            <a 
              href="#" 
              className="text-usbank-blue hover:underline cursor-pointer"
              data-testid="link-full-search"
            >
              Search full U.S. Bank website
            </a>
          </div>

          <div className="mb-6">
            <h3 className="font-semibold mb-2" data-testid="heading-search-tips">
              Search tips
            </h3>
            <ul className="text-gray-600 space-y-1">
              <li>• Make sure keywords are spelled correctly.</li>
              <li>• Try entering fewer keywords.</li>
              <li>• Try using an alternate keyword.</li>
            </ul>
          </div>
        </div>
      )}
    </section>
  );
}
