import { Card, CardContent } from "@/components/ui/card";
import digitalExplorerImg from "@assets/photo-woman-using-mobile-device-and-laptop-16x9_1755157864488.jpg";
import financialEducationImg from "@assets/photo-man-hold-clipbaord-and-smiling-16x9_1755157940863.jpg";
import newsroomImg from "@assets/photo-couple-sitting-in-front-of-home-16x9_1755158006429.jpg";

const sections = [
  {
    title: "U.S. Bank Digital Explorer",
    subtitle: "Interactive tutorials for digital banking",
    description: "Learn to bank in the U.S. Bank Mobile App and online banking with simple, interactive demos for everyday tasks.",
    linkText: "Visit U.S. Bank Digital Explorer",
    href: "#",
    imageUrl: digitalExplorerImg,
    imageAlt: "Woman using mobile device and laptop for banking"
  },
  {
    title: "Financial education",
    subtitle: "Your financial questions, answered",
    description: "Check out these helpful articles to learn more about personal finance, or brush up on your money knowledge.",
    linkText: "Visit FinancialIQ",
    href: "#",
    imageUrl: financialEducationImg,
    imageAlt: "Professional man with clipboard smiling in office"
  },
  {
    title: "Newsroom",
    subtitle: "What's happening at U.S. Bank",
    description: "Read up on the latest news, announcements and stories from U.S. Bank.",
    linkText: "Visit Newsroom",
    href: "#",
    imageUrl: newsroomImg,
    imageAlt: "Happy couple sitting in front of home"
  }
];

export default function StayInTheKnow() {
  return (
    <section className="mb-16">
      <h2 className="text-2xl font-semibold text-usbank-blue mb-8" data-testid="heading-stay-in-know">
        Stay in the know
      </h2>
      
      <div className="grid lg:grid-cols-3 gap-8">
        {sections.map((section, index) => (
          <Card key={index} className="border-gray-200 shadow-sm overflow-hidden">
            <img
              src={section.imageUrl}
              alt={section.imageAlt}
              className="w-full h-48 object-cover"
              data-testid={`img-section-${index}`}
            />
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold text-usbank-blue mb-2" data-testid={`heading-section-${index}`}>
                {section.title}
              </h3>
              <p className="text-gray-600 mb-4 text-sm font-medium" data-testid={`subtitle-section-${index}`}>
                {section.subtitle}
              </p>
              <p className="text-gray-700 mb-6" data-testid={`description-section-${index}`}>
                {section.description}
              </p>
              <a
                href={section.href}
                className="text-usbank-blue hover:underline font-medium"
                data-testid={`link-section-${index}`}
              >
                {section.linkText}
              </a>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
