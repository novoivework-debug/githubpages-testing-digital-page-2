import { Card, CardContent } from "@/components/ui/card";

const topicsData = [
  {
    title: "Manage settings & scheduling",
    links: [
      { text: "Reset my password", href: "#" },
      { text: "I forgot my username", href: "#" },
      { text: "Update my contact information", href: "#" },
      { text: "Schedule an appointment with a banker", href: "#" }
    ]
  },
  {
    title: "Account setup & information",
    links: [
      { text: "Order checks", href: "#" },
      { text: "Find my routing number", href: "#" },
      { text: "Activate my debit card", href: "#" },
      { text: "Set up direct deposit", href: "#" }
    ]
  },
  {
    title: "Credit cards",
    links: [
      { text: "Activate my credit card", href: "#" },
      { text: "View or redeem credit card rewards", href: "#" },
      { text: "Request a credit card balance transfer", href: "#" },
      { text: "Check my credit score", href: "#" }
    ]
  },
  {
    title: "Payments and billing",
    links: [
      { text: "Send a wire transfer", href: "#" },
      { text: "Send a money order or cashier's check", href: "#" },
      { text: "Pay my mortgage", href: "#" },
      { text: "Pay bills", href: "#" }
    ]
  }
];

export default function PopularTopics() {
  return (
    <section className="mb-16">
      <h2 className="text-2xl font-semibold text-usbank-blue mb-8" data-testid="heading-popular-topics">
        All popular topics
      </h2>
      
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {topicsData.map((topic, index) => (
          <Card key={index} className="border-gray-200 shadow-sm">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4 text-usbank-blue" data-testid={`heading-topic-${index}`}>
                {topic.title}
              </h3>
              <ul className="space-y-3">
                {topic.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href={link.href}
                      className="text-usbank-blue hover:underline text-sm"
                      data-testid={`link-topic-${index}-${linkIndex}`}
                    >
                      {link.text}
                    </a>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
