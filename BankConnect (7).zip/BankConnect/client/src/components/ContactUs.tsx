import { Calendar, Phone, MapPin } from "lucide-react";

const contactOptions = [
  {
    icon: Calendar,
    title: "Schedule",
    linkText: "Make an appointment",
    href: "#"
  },
  {
    icon: Phone,
    title: "Call",
    linkText: "800-USBANKS",
    href: "tel:8008722657"
  },
  {
    icon: MapPin,
    title: "Visit",
    linkText: "Find a branch",
    href: "#"
  }
];

export default function ContactUs() {
  return (
    <section className="mb-16">
      <h2 className="text-2xl font-semibold text-usbank-blue mb-8" data-testid="heading-contact-us">
        Contact us
      </h2>
      <div className="bg-usbank-light-gray rounded-lg p-8">
        <div className="grid sm:grid-cols-3 gap-6">
          {contactOptions.map((option, index) => {
            const IconComponent = option.icon;
            return (
              <div key={index} className="text-center">
                <div className="bg-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 shadow-sm">
                  <IconComponent className="text-usbank-blue text-xl w-6 h-6" data-testid={`icon-contact-${index}`} />
                </div>
                <h3 className="font-semibold mb-2" data-testid={`title-contact-${index}`}>
                  {option.title}
                </h3>
                <a
                  href={option.href}
                  className="text-usbank-blue hover:underline"
                  data-testid={`link-contact-${index}`}
                >
                  {option.linkText}
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
