import { Facebook, Twitter, Instagram } from "lucide-react";

const footerSections = [
  {
    title: "Support",
    links: [
      { text: "Site map", href: "#" },
      { text: "Online tracking & advertising", href: "#" },
      { text: "Your privacy choices", href: "#", hasIcon: true }
    ]
  },
  {
    title: "Security",
    links: [
      { text: "Careers", href: "#" },
      { text: "Alumni", href: "#" },
      { text: "Cobrowse", href: "#" }
    ]
  },
  {
    title: "Financial education",
    links: [
      { text: "Accessibility", href: "#" },
      { text: "Privacy", href: "#" }
    ]
  }
];

export default function Footer() {
  return (
    <footer className="bg-usbank-blue text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Social Media Icons */}
        <div className="flex space-x-4 mb-8">
          <a 
            href="#" 
            className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors"
            data-testid="link-facebook"
          >
            <Facebook className="w-5 h-5 text-usbank-blue" />
          </a>
          <a 
            href="#" 
            className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors"
            data-testid="link-twitter"
          >
            <Twitter className="w-5 h-5 text-usbank-blue" />
          </a>
          <a 
            href="#" 
            className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors"
            data-testid="link-instagram"
          >
            <Instagram className="w-5 h-5 text-usbank-blue" />
          </a>
        </div>

        {/* Footer Content */}
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {footerSections.map((section, index) => (
            <div key={index}>
              <h4 className="font-normal mb-4 text-white" data-testid={`heading-footer-${index}`}>
                {section.title}
              </h4>
              <ul className="space-y-3 text-sm">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href={link.href}
                      className="text-white hover:underline font-normal flex items-center"
                      data-testid={`link-footer-${index}-${linkIndex}`}
                    >
                      {link.text}
                      {link.hasIcon && (
                        <span className="ml-2 text-xs bg-blue-600 px-1 py-0.5 rounded">
                          ✓
                        </span>
                      )}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          
          {/* Address Section */}
          <div>
            <h4 className="font-normal mb-4 text-white" data-testid="heading-address">
              U.S. Bank
            </h4>
            <div className="text-sm text-white space-y-1">
              <p data-testid="text-address-line1">800 Nicollet Mall</p>
              <p data-testid="text-address-line2">Minneapolis, MN 55402</p>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-8 text-sm text-white">
          <p data-testid="text-copyright">
            © 2025 U.S. Bank
          </p>
        </div>
      </div>
    </footer>
  );
}
