import { Card, CardContent } from "@/components/ui/card";

const serviceAreas = [
  { title: "Personal Banking", href: "#" },
  { title: "Wealth Management", href: "#" },
  { title: "Business Banking", href: "#" },
  { title: "Corporate & Commercial", href: "#" }
];

export default function CustomerServiceAreas() {
  return (
    <section className="mb-16">
      <h2 className="text-2xl font-semibold text-usbank-blue mb-8" data-testid="heading-service-areas">
        Customer service areas
      </h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {serviceAreas.map((area, index) => (
          <Card key={index} className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <h3 className="font-semibold mb-2">
                <a
                  href={area.href}
                  className="text-usbank-blue hover:underline"
                  data-testid={`link-service-area-${index}`}
                >
                  {area.title}
                </a>
              </h3>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
