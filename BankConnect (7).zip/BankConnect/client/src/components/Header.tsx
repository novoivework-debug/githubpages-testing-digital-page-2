import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import usBankLogo from "@assets/US_Bank_2022_1755159207876.webp";

export default function Header() {
  return (
    <>
      {/* Main Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center">
              <img 
                src={usBankLogo} 
                alt="US Bank" 
                className="h-6 w-auto"
                data-testid="logo"
              />
            </div>
            
            {/* Navigation */}
            <nav className="hidden md:block">
              <div className="flex items-center space-x-8">
                <a 
                  href="#" 
                  className="text-gray-700 hover:text-usbank-blue px-3 py-2 text-sm font-medium"
                  data-testid="link-personal"
                >
                  Personal
                </a>
                <a 
                  href="#" 
                  className="text-gray-700 hover:text-usbank-blue px-3 py-2 text-sm font-medium"
                  data-testid="link-wealth-management"
                >
                  Wealth Management
                </a>
                <a 
                  href="#" 
                  className="text-gray-700 hover:text-usbank-blue px-3 py-2 text-sm font-medium"
                  data-testid="link-business"
                >
                  Business
                </a>
                <a 
                  href="#" 
                  className="text-gray-700 hover:text-usbank-blue px-3 py-2 text-sm font-medium"
                  data-testid="link-corporate-commercial"
                >
                  Corporate & Commercial
                </a>
                <a 
                  href="#" 
                  className="text-gray-700 hover:text-usbank-blue px-3 py-2 text-sm font-medium"
                  data-testid="link-institutional"
                >
                  Institutional
                </a>
              </div>
            </nav>
            
            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-gray-700 hover:text-usbank-blue"
                data-testid="button-mobile-menu"
              >
                <Menu className="h-6 w-6" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Breadcrumb Navigation */}
      <div className="bg-gray-50 border-b border-gray-200 py-3">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="text-sm" data-testid="breadcrumb">
            <a href="#" className="text-gray-600 hover:text-usbank-blue">Home</a>
            <span className="mx-2 text-gray-400">/</span>
            <span className="text-gray-900">Customer service</span>
          </nav>
        </div>
      </div>
    </>
  );
}
