import { useEffect } from "react";
import Header from "@/components/Header";
import SearchSection from "@/components/SearchSection";
import PopularTopics from "@/components/PopularTopics";
import CustomerServiceAreas from "@/components/CustomerServiceAreas";
import StayInTheKnow from "@/components/StayInTheKnow";
import ContactUs from "@/components/ContactUs";
import Footer from "@/components/Footer";

export default function CustomerService() {
  useEffect(() => {
    document.title = "U.S. Bank Customer Service & Contact Us";
    
    // Add meta description for SEO
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', 'Get help with your U.S. Bank accounts, credit cards, loans, and more. Search customer service topics, find answers, or contact us for personalized assistance.');
    } else {
      const meta = document.createElement('meta');
      meta.name = 'description';
      meta.content = 'Get help with your U.S. Bank accounts, credit cards, loans, and more. Search customer service topics, find answers, or contact us for personalized assistance.';
      document.head.appendChild(meta);
    }

    // Add Open Graph tags
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (!ogTitle) {
      const meta = document.createElement('meta');
      meta.setAttribute('property', 'og:title');
      meta.content = 'U.S. Bank Customer Service & Contact Us';
      document.head.appendChild(meta);
    }

    const ogDescription = document.querySelector('meta[property="og:description"]');
    if (!ogDescription) {
      const meta = document.createElement('meta');
      meta.setAttribute('property', 'og:description');
      meta.content = 'Get help with your U.S. Bank accounts, credit cards, loans, and more. Search customer service topics, find answers, or contact us.';
      document.head.appendChild(meta);
    }
  }, []);

  return (
    <div className="font-inter bg-white text-gray-900 min-h-screen">
      <Header />
      
      <main id="main-content" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Title Section */}
        <div className="mb-8">
          <p className="text-gray-500 text-sm uppercase tracking-wide mb-2" data-testid="page-category">
            U.S. BANK CUSTOMER SERVICE & CONTACT US
          </p>
          <h1 className="text-3xl font-normal text-gray-900 mb-4" data-testid="heading-page-title">
            U.S. Bank customer service & contact us
          </h1>
          <p className="text-gray-600 text-base max-w-2xl mb-4">
            Get help with your banking needs. Search our help topics, browse popular questions, or contact us directly for personalized assistance.
          </p>
          <a 
            href="#search-section" 
            className="text-usbank-blue hover:underline font-medium text-sm"
            data-testid="link-skip-to-main"
          >
            Skip to main content
          </a>
        </div>

        <div id="search-section">
          <SearchSection />
        </div>
        <PopularTopics />
        <CustomerServiceAreas />
        <StayInTheKnow />
        <ContactUs />
      </main>

      <Footer />
    </div>
  );
}
